
import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;

void main() {
  runApp(DadiFood());
}

class DadiFood extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Home(),
    );
  }
}

class Home extends StatefulWidget {
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String result = "Scan a product";
  String score = "";

  Future<void> fetchProduct(String code) async {
    final url = "https://world.openfoodfacts.org/api/v0/product/$code.json";
    final res = await http.get(Uri.parse(url));
    final data = json.decode(res.body);

    if (data["product"] != null) {
      var p = data["product"];
      String ing = (p["ingredients_text"] ?? "").toString().toLowerCase();

      int s = 100;
      if (ing.contains("sugar")) s -= 30;
      if (ing.contains("oil")) s -= 10;
      if (ing.contains("e")) s -= 20;

      setState(() {
        result = p["product_name"] ?? "Unknown";
        score = s > 70 ? "🟢 Good" : s > 40 ? "🟡 Medium" : "🔴 Bad";
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Dadi Food"),
        centerTitle: true,
      ),
      body: Column(
        children: [
          Expanded(
            child: MobileScanner(
              onDetect: (capture) {
                final code = capture.barcodes.first.rawValue;
                if (code != null) {
                  fetchProduct(code);
                }
              },
            ),
          ),
          Container(
            padding: EdgeInsets.all(20),
            child: Column(
              children: [
                Text(result, style: TextStyle(fontSize: 18)),
                SizedBox(height: 10),
                Text(score, style: TextStyle(fontSize: 22)),
              ],
            ),
          )
        ],
      ),
    );
  }
}
