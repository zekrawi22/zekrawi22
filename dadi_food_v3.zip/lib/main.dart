
import 'package:flutter/material.dart';
import 'scanner_page.dart';

void main() {
  runApp(DadiFoodApp());
}

class DadiFoodApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Dadi Food',
      theme: ThemeData(
        primarySwatch: Colors.green,
        fontFamily: 'Roboto',
      ),
      home: ScannerPage(),
    );
  }
}
