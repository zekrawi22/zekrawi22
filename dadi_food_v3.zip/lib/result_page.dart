
import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class ResultPage extends StatefulWidget {
  final String barcode;
  ResultPage({required this.barcode});

  @override
  _ResultPageState createState() => _ResultPageState();
}

class _ResultPageState extends State<ResultPage> {
  Map? product;
  int score = 0;
  bool isFavorite = false;

  @override
  void initState() {
    super.initState();
    fetchProduct();
    checkFavorite();
  }

  int calculateScore(Map product) {
    int s = 100;
    var nutriments = product['nutriments'] ?? {};

    double sugar = nutriments['sugars_100g'] ?? 0;
    double salt = nutriments['salt_100g'] ?? 0;
    double fat = nutriments['fat_100g'] ?? 0;

    if (sugar > 10) s -= 30;
    if (salt > 1) s -= 20;
    if (fat > 15) s -= 15;

    if (product['additives_tags'] != null) {
      s -= (product['additives_tags'].length * 5);
    }

    return s.clamp(0, 100);
  }

  fetchProduct() async {
    final res = await http.get(Uri.parse(
        "https://world.openfoodfacts.org/api/v0/product/${widget.barcode}.json"));
    final data = json.decode(res.body);

    setState(() {
      product = data['product'];
      if (product != null) {
        score = calculateScore(product!);
      }
    });
  }

  toggleFavorite() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> favs = prefs.getStringList("favorites") ?? [];

    if (favs.contains(widget.barcode)) {
      favs.remove(widget.barcode);
      isFavorite = false;
    } else {
      favs.add(widget.barcode);
      isFavorite = true;
    }

    await prefs.setStringList("favorites", favs);
    setState(() {});
  }

  checkFavorite() async {
    final prefs = await SharedPreferences.getInstance();
    List<String> favs = prefs.getStringList("favorites") ?? [];
    setState(() {
      isFavorite = favs.contains(widget.barcode);
    });
  }

  Color getColor() {
    if (score > 70) return Colors.green;
    if (score > 40) return Colors.orange;
    return Colors.red;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Dadi Food"),
        actions: [
          IconButton(
            icon: Icon(isFavorite ? Icons.favorite : Icons.favorite_border),
            onPressed: toggleFavorite,
          )
        ],
      ),
      body: product == null
          ? Center(child: CircularProgressIndicator())
          : Padding(
              padding: EdgeInsets.all(16),
              child: ListView(
                children: [
                  Text(product!['product_name'] ?? "Unknown",
                      style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),

                  SizedBox(height: 10),
                  Text("Brand: ${product!['brands'] ?? 'N/A'}"),

                  SizedBox(height: 20),

                  Container(
                    padding: EdgeInsets.all(20),
                    decoration: BoxDecoration(
                      color: getColor().withOpacity(0.2),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Column(
                      children: [
                        Text("Score",
                            style: TextStyle(fontSize: 18)),
                        SizedBox(height: 10),
                        Text("$score / 100",
                            style: TextStyle(
                                fontSize: 26,
                                fontWeight: FontWeight.bold,
                                color: getColor())),
                      ],
                    ),
                  ),

                  SizedBox(height: 20),

                  Text("NutriScore: ${product!['nutriscore_grade'] ?? 'N/A'}"),

                  SizedBox(height: 20),

                  Text("Developed by Zoudadi ®",
                      style: TextStyle(fontSize: 12, color: Colors.grey)),
                ],
              ),
            ),
    );
  }
}
